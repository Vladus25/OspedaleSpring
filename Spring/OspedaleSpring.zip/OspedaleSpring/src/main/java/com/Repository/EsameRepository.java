package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.EsameEntity;

public interface EsameRepository extends JpaRepository<EsameEntity, Integer>{

}
